export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') return res.status(200).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  const { prompt } = req.body;
  if (!prompt) return res.status(400).json({ error: 'Prompt required' });

  const GEMINI_KEY = process.env.GEMINI_API_KEY;

  const systemPrompt = `You are PreciseVibe AI — expert web developer. Generate complete stunning single-file HTML websites.

RULES:
1. Return ONLY raw HTML. No markdown, no backticks, no explanation.
2. Single self-contained HTML file with embedded CSS and JS.
3. Use CDN links for libraries.
4. Detect keywords:
   - "3D" / "car" / "product" → Three.js r128 from cdnjs
   - "animation" / "scroll" → GSAP from cdnjs
   - "glass" / "glassmorphism" → CSS backdrop-filter
   - "neon" / "dark" → dark theme neon glows
   - "luxury" / "premium" → elegant gold accents
5. Always include: smooth scroll, mobile responsive, Google Fonts, hover animations.
6. Make it VISUALLY STUNNING and professional.

CRITICAL: Start with <!DOCTYPE html> end with </html>. Nothing else.`;

  try {
    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${GEMINI_KEY}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contents: [{ parts: [{ text: `${systemPrompt}\n\nUser request: ${prompt}` }] }],
          generationConfig: { temperature: 0.9, maxOutputTokens: 8192 }
        })
      }
    );
    const data = await response.json();
    if (!response.ok) throw new Error(data.error?.message || 'Gemini API error');
    let html = data.candidates?.[0]?.content?.parts?.[0]?.text || '';
    html = html.replace(/```html/gi, '').replace(/```/g, '').trim();
    if (!html.includes('<!DOCTYPE') && !html.includes('<html')) throw new Error('Invalid HTML');
    res.status(200).json({ html });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}
